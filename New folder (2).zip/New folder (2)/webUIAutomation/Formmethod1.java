package webUIAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Formmethod1 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
		
	   driver.get("http://studentuniverse.com");
	
	   //.isDisplayed(): method is used to check whether the object is visible during one operation 
	   // and not visible(Hidden) during another operation
	   
	   driver.findElement(By.xpath(".//span[@su-translate='terms.tripType.label']")).click();
	  System.out.println("When Roundtrip is clicked");
	 //  driver.findElement(By.xpath(".//*[@id='trip_type_round']")).click();
	   
	   System.out.println(driver.findElement(By.xpath(".//input[@placeholder='Return']")).isDisplayed());
	   
	   System.out.println("When Multicity is clicked");
	   driver.findElement(By.xpath(".//span[@id='trip_type_multi']")).click();
	   
	   //System.out.println(driver.findElement(By.xpath(".//input[@placeholder='Return']")).isDisplayed());

	   //.isDisplayed method will work only when there is something present in the code and is 
	   //not displayed means when only in Hidden mode. If the code is not present itself , it will not function
	   
	   //Lots of difference between Hidden code and code not present in the webpage
	   
	   int count = driver.findElements(By.xpath(".//input[@placeholder='Return']")).size();
	   
	   if (count == 0)
	   {
		   System.out.println("The Retun Date is not there and it is VERIFIED");
	   }
	   
	}

}
