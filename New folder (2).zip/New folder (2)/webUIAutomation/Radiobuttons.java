package webUIAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Radiobuttons {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","E:\\Downloads For Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://www.southwest.com");
		
	//driver.findElement(By.xpath("//input[@id='trip-type-one-way']")).click();
	System.out.println(driver.findElement(By.xpath("//input[@id='trip-type-one-way']")).isSelected());
	System.out.println(driver.findElements(By.xpath("//input[@name='twoWayTrip']")).size());
	
	int count = driver.findElements(By.xpath("//input[@name='twoWayTrip']")).size();
	
	for(int i=0; i<count; i++)
	{
		driver.findElements(By.xpath("//input[@name='twoWayTrip']")).get(i).click();
		System.out.println(driver.findElements(By.xpath("//input[@name='twoWayTrip']")).get(i).getAttribute("id"));
		
		String mytext =driver.findElements(By.xpath("//input[@name='twoWayTrip']")).get(i).getAttribute("id");
	
				if(mytext.equals("trip-type-round-trip"))
				{
					driver.findElements(By.xpath("//input[@name='twoWayTrip']")).get(i).click();
				}
				
	}
	
	
	}

}
