package webUIAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class Dynamicdropdown 
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","E:\\Downloads For Selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
	
		driver.get("http://www.spicejet.com/");
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		driver.findElement(By.cssSelector("a[value='RJA']")).click();
		
		//STATIC DROPDOWN ---> SELECT CLASS is used
		
		Select staticdrop = new Select(driver.findElement(By.xpath("//*[@id='ctl00_mainContent_ddl_Adult']")));
		staticdrop.selectByValue("5");
		staticdrop.selectByIndex(5);
		
		
	}
}
