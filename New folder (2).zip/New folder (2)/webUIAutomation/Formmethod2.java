package webUIAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Formmethod2 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
		
		//.isEnabled is used to check whether the particular UI function is enabled or not 
		
		   driver.get("http://southwest.com");
		   System.out.println("When Roundtrip is clicked and Return Date is Enabled");
		   System.out.println(driver.findElement(By.xpath(".//*[@id='air-date-return']")).isEnabled());
		   System.out.println("When Oneway is clicked and Return Date is Disabled");
		   driver.findElement(By.xpath(".//*[@id='trip-type-one-way']")).click();
		  System.out.println(driver.findElement(By.xpath(".//*[@id='air-date-return']")).isEnabled());

	}

}
