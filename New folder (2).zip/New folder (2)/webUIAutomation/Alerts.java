package webUIAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Alerts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		WebDriver driver = new FirefoxDriver();
		
	//Alert --> It is a non Html alert.That is when you point on that alert no HTML code you will find
		
		driver.get("http://www.tizag.com/javascriptT/javascriptalert.php");
		
		driver.findElement(By.cssSelector("input[value='Confirmation Alert']")).click();
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept(); // OK Done Accept ---> for Positive Scenarios
		//driver.switchTo().alert().dismiss(); // cancel ----> for negative Scenarios

		//driver.get("https://www.goindigo.in/");
		//driver.switchTo().alert().dismiss();
		//driver.findElement(By.cssSelector("div[id='bookingflightTab']")).click();
		//driver.findElement(By.linkText("#oneWay")).click();
	
	}
	
	

}
