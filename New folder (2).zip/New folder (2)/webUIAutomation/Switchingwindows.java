package webUIAutomation;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Switchingwindows {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		WebDriver driver = new FirefoxDriver();
	    driver.get("http://facebook.com");
	    driver.findElement(By.cssSelector("a[href='/legal/terms']")).click();
	    System.out.println(driver.getTitle());
	    Set<String>id = driver.getWindowHandles();
	   Iterator<String>window=id.iterator();
	   String parent = window.next();
	   String child = window.next();
	   driver.switchTo().window(child);
	   System.out.println(window);
	   System.out.println(child);
	   System.out.println(parent);
	   System.out.println(driver.getTitle());
	  driver.findElement(By.xpath("//a[@href='/about/privacy/']")).click();
	 	}

}
