package webUIAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;


public class ActionExample
{

	//Actions is used for the keyboard and mouse movements
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("http://amazon.com");
		Actions myword = new Actions(driver);
		
		WebElement Element = driver.findElement(By.xpath(".//*[@id='nav-link-yourAccount']"));
	
		myword.moveToElement(Element).build().perform();
		
		driver.findElement(By.xpath(".//*[@id='nav-search']")).click();
		//driver.findElement(By.xpath(".//*[@id='nav-search']")).sendKeys("books");
		
		WebElement elem = driver.findElement(By.xpath(".//*[@id='twotabsearchtextbox']"));
		
		myword.keyDown(Keys.SHIFT).moveToElement(elem).sendKeys("books").build().perform();
		
		myword.contextClick(elem).build().perform(); //Right click action  is referred as Contextclick() 
	}

}
