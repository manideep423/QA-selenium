package gridconcept;

import java.net.MalformedURLException;
import java.net.URL;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class SauceLabs 
{
	@Test

	public static void main(String[] args) throws MalformedURLException 
	{
		// TODO Auto-generated method stub
		
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setCapability("Version", "2");
        cap.setCapability("Platform", "xp");
        
        WebDriver mydrive = new RemoteWebDriver(new URL("http://prajnesh:0635c334-b8ac-4c12-ac0a-396e61acbdbe@onedemand.Saucelabs.com:80/wd/hub"), cap);
	mydrive.get("http://svbcttd.com");
	System.out.println(mydrive.getTitle());
	//http://Saucelabid:Accesskey@onedemand.Saucelabs.com:80/wd/hub
	}

}
