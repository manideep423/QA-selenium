package gridconcept;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class runningremotely {

	//private static final String FirefoxDriver = null;

	public static void main(String[] args) throws MalformedURLException 
	
	{
		// TODO Auto-generated method stub

		WebDriver mydrive;
		
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability(FirefoxDriver.BINARY,new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe").getAbsolutePath());
	
	
	mydrive = new RemoteWebDriver(new URL("http://192.168.1.174:5566/wd/hub"),capabilities);
	
	mydrive.get("http://facebook.com");
	System.out.println(mydrive.getTitle());
	
	}

}
