package Seleniumbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatorObjects1
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
WebDriver driver = new FirefoxDriver();

driver.get("http://svbcttd.com");
driver.findElement(By.xpath("html/body/div[2]/div[1]/a[2]")).click();
System.out.println(driver.getTitle());
	}

}
