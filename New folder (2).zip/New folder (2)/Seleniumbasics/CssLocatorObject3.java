package Seleniumbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CssLocatorObject3 
{

	public static void main(String[] args)
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://svbcttd.com");
		
		driver.findElement(By.cssSelector("a[class='telugu-title']")).click();
		
	}



}




