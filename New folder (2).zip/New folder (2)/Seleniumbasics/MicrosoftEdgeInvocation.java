package Seleniumbasics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class MicrosoftEdgeInvocation
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.ie.driver", "E:\\Downloads For Selenium\\MicrosoftWebDriver.msi");
		WebDriver driver = new InternetExplorerDriver();
		driver.get("//http:google.com");
		

	}

}
