package Seleniumbasics;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatorObject2

{

	public static void main(String args[])
	{
		WebDriver driver = new FirefoxDriver();

	driver.get("http://facebook.com");
		driver.findElement(By.id("email")).sendKeys("prajnesh@hotmail.com");
		driver.findElement(By.linkText("Forgot account?")).click();
	
		//driver.findElement(By.name("pass")).sendKeys("kulu");
		//driver.findElement(By.xpath(".//*[@id='u_0_o']")).click(); 
	
	
		/*driver.findElement(By.className("placeholder has-focus")).sendKeys("prajnesheric@hotmail.com");
		driver.findElement(By.xpath(".//*[@id='CredentialsInputPane']/div[4]/div[2]/div/fieldset/div[2]/div/div/div/div/div")).sendKeys("book3");
		driver.findElement(By.xpath(".//*[@id='idSIButton9']")).click(); */
		
		List<WebElement> allLink = driver.findElements(By.tagName("a"));
		System.out.println("Number of Links:-"+allLink.size());
	
	}
}
