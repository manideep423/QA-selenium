package Seleniumbasics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserInvocation
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Selenium Code:
		
	WebDriver driver = new FirefoxDriver();
	driver.get("http://www.svbcttd.com/Telugu.html"); //Get to hit the URL
	
	//driver. ---> will give you the all listings
	
	System.out.println(driver.getTitle());  // title of the page
	System.out.println(driver.getPageSource()); //Page source details
	System.out.println(driver.getCurrentUrl()); //For current URL and check whether the website you mentioned in get() is navigating to same address;
	driver.close();
	}

}
