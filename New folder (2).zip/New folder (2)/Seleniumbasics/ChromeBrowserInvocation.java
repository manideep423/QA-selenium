package Seleniumbasics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeBrowserInvocation
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Chrome is built by third part persons,
		// So it should need a .exe file to be loaded before the actual driver runs;
		//Similarly with Internet explorer
		
		
		System.setProperty("webdriver.chrome.driver","E:\\Downloads For Selenium\\chromedriver_win32\\chromedriver.exe");
		
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://youtube.com");
		System.out.println(driver.getTitle());
		System.out.println(driver.getPageSource());
		
		
	}

}
