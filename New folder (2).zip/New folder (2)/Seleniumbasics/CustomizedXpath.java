package Seleniumbasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CustomizedXpath

{

	public static void main(String[] args)
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://svbcttd.com");
		
		
		
//Syntax for Customized xpath -->  //Tagname[@attribute='value']
		// Tag name is the first sentence in the line after <
		//You can give any attribute; But always choose a unique Attribute

		driver.findElement(By.xpath("//a[@class='telugu-title']")).click();
	}
}