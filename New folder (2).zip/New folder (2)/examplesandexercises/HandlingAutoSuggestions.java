package examplesandexercises;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandlingAutoSuggestions
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		WebDriver mydrive = new FirefoxDriver();
		
		mydrive.get("https://fantasycricket.dream11.com/us/");
		mydrive.findElement(By.xpath("//input[@id='m_rtxtEmail1']")).sendKeys("prajnesh");
		WebDriverWait wt = new WebDriverWait(mydrive, 5);
		//WebDriverWait wait is an explicit wait which is different from normal implicit wait thread.sleep wait() 
		//explicit wait will only wait until the execution occurred and run the script after that without waiting for total sleep period
		
		//avoid using implicit wait in your scripts
		
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath(".//*[@id='m_frmRegister']/div[1]/ul")));
		
		mydrive.findElement(By.xpath(".//*[@id='m_frmRegister']/div[1]/ul/li[6]/p")).click();
	

	}

}
