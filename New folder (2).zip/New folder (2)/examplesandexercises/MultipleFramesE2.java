package examplesandexercises;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MultipleFramesE2 

{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		WebDriver mydrive = new FirefoxDriver();
		
		mydrive.get("https://spinbot.com/");
		
		int framenumber = FindFramenumber(mydrive,By.xpath(".//*[@id='recaptcha-anchor']/div[5]"));
		System.out.println("Framenumner in which our desired frame is found: " + framenumber);
		mydrive.switchTo().frame(framenumber);
		mydrive.findElement(By.xpath("//*[@id='recaptcha-anchor']/div[5]")).click();
		
		mydrive.switchTo().defaultContent();
		
		int framenumber1 = FindFramenumber(mydrive,By.xpath(".//*[@id='recaptcha-verify-button']"));
		System.out.println("Framenumner in which our desired frame is found: " + framenumber1);
		mydrive.switchTo().frame(framenumber1);
		mydrive.findElement(By.xpath(".//*[@id='recaptcha-verify-button']")).click();
	
		
		

	}

	public static int FindFramenumber(WebDriver mydrive, By by)
	{
		int i; 
		int totalframes = mydrive.findElements(By.tagName("iframe")).size();
		System.out.println("The Total Number of iframes found : " + totalframes);
		
		
		for(i=0;i<totalframes;i++)
       {
			mydrive.switchTo().frame(i);
		
			int count = mydrive.findElements(by).size();
	
        if(count>0)
        {
        	 //mydrive.findElement(by).click();
        	break;
        }
        
        else
        {
        	System.out.println("Proceed the Loop frame not found");
        }
       
        mydrive.switchTo().defaultContent();	
       }
		
		mydrive.switchTo().defaultContent();	
		return i;
		
		
		
	}
}
