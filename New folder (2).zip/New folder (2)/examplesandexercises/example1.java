package examplesandexercises;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import junit.framework.Assert;

public class example1 {

	
	//Counting Number of LINKS in an website and NUmber of Links in the Footer Section 
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		WebDriver mydrive = new FirefoxDriver();
		
		mydrive.get("https://www.amazon.com/");
		
		//Counting number of links in the webpage	
		System.out.println("Total Number of Links in the Webpage : ");	
		System.out.println(mydrive.findElements(By.tagName("a")).size());
		
	
		//Counting number of links in the footer section
		WebElement footersection = mydrive.findElement(By.xpath(".//*[@id='navFooter']"));
		System.out.println("Total Number of Links in the Footer : ");
		System.out.println(footersection.findElements(By.tagName("a")).size());
	
		//Counting number of links in Specified Footer Column
		WebElement footercolumn = mydrive.findElement(By.xpath(".//*[@id='navFooter']/table/tbody/tr/td[3]"));
		System.out.println("Total Number of Links in the Footer Column : ");
		System.out.println(footercolumn.findElements(By.tagName("a")).size());
		
		System.out.println("Link Names : ");
	// System.out.println(footercolumn.getText());
	//or
		
		String BeforeClickig = null;
		
		int linksize = footercolumn.findElements(By.tagName("a")).size();
		for(int i=0; i<linksize; i++) //linksize is given just to modify the lengthy for loop 
		{
			System.out.println(i + "." + footercolumn.findElements(By.tagName("a")).get(i).getText() );
			
			if(footercolumn.findElements(By.tagName("a")).get(i).getText().contains("Become an Amazon Vendor"))
			{
				BeforeClickig = mydrive.getTitle();
				
				footercolumn.findElements(By.tagName("a")).get(i).click(); //Cliking on the link with out knowing where exaclty it is in the footer Column
				break;
				
			}
		}

		//mydrive.findElement(By.xpath("//a[@href='/b/ref=footer_vend?ie=UTF8&node=10659983011']")).click();
	
		
		String AfterClicking = mydrive.getTitle();
		
		System.out.println("Total Number of Links after the new page is Opened: ");	
		System.out.println(mydrive.findElements(By.tagName("a")).size());
		
	
		
		if(BeforeClickig != AfterClicking)
		{
		   
		System.out.println(mydrive.findElement(By.xpath("//img[@title='Vendor Express']")).isDisplayed());	
			System.out.println("Passed");
		    
		}
			else
		{
				System.out.println("Failed");	
				
		}
			
		
		
	
		
	}
	
	

}
