package testng;

import org.testng.annotations.Test;

public class Dependencyatt {
	
	@Test
	public void Browser(){
		
		System.out.println("opening browser");
		
		
	}
	@Test(dependsOnMethods={"Browser"})
	public void Flightbooking(){
		
		System.out.println("flight booking page opens");
		
		
	}

}
