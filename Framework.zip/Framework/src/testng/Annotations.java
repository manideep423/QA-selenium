package testng;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Annotations {
	
	@AfterMethod
	public void Aft(){
		
		System.out.println("THIS BLOCK EXECUTES AFTER EACH TEST ");
	}
	@BeforeMethod
	public void Bef(){
		
		System.out.println("THIS BLOCK EXECUTES BEFORE EACH TEST ");
	}
	
	@BeforeTest
	public void abc(){
		
		System.out.println("should show BEFORE all tests");
		
	}
	@Test
	public void Browser(){
		
		System.out.println("1111111");
		
		
	}
	@Test
	public void Browse(){
		
		System.out.println("2222222");
		
		
	}
	@Test
	public void Brows(){
		
		System.out.println("3333333");
		
		
	}
	@Test
	public void Bro(){
		
		System.out.println("44444444");
		
		
	}
	@Test
	public void Br(){
		
		System.out.println("55555555");
		
		
	}
	@AfterTest
	
	public void ending(){
		
		System.out.println("should show AFTER all tests");
		
		
	}
}
