package testng;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

public class Prop {
	@Test
	public void login() throws IOException{
		Properties prop=new Properties();
		FileInputStream fis=new FileInputStream("C:\\Users\\MANI\\workspace\\Framework\\src\\testng\\datadriv");
		prop.load(fis);
		System.out.println("username");
		
	}

}
