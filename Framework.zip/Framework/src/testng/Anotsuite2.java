package testng;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class Anotsuite2 {
	
	@BeforeSuite
	public void abc(){
		
		System.out.println("I AM THE FIRST");
		
	}
	@AfterSuite
	public void abcd(){
		
		System.out.println("I AM THE LAST");
		
	}


}
