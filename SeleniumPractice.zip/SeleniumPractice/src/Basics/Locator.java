package Basics;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Locator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver loc=new FirefoxDriver();
		loc.get("http://facebook.com");
		loc.findElement(By.id("email")).sendKeys("mani.51561@gmail.com");
		loc.findElement(By.id("pass")).sendKeys("12345");
		loc.findElement(By.xpath("html/body/div[1]/div[1]/div/div/div/div/div[2]/form/table/tbody/tr[2]/td[3]/label/input")).click();
		//loc.findElement(By.linkText("Forgotten account?")).click();
	}

}
