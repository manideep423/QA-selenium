package Basics;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdowns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driv=new FirefoxDriver();
		
		driv.get("http://jetairways.com");
		driv.findElement(By.xpath("//input[@id='ObeFlights1_autoOrigin_AutoText']")).click();
		driv.findElement(By.xpath("html/body/form/div[4]/div[1]/div/div/section/div[2]/div[2]/div/div[1]/div[2]/div[1]/ul/li[3]/span[1]")).click();
		driv.findElement(By.xpath("html/body/form/div[4]/div[1]/div/div/section/div[2]/div[2]/div/div[2]/div[1]/input[1]")).click();
		driv.findElement(By.xpath("//input[@id='noOfTravellers']")).click();
		driv.findElement(By.xpath("//select[@id='ddlAdult']")).click();
		
		Select drop=new Select(driv.findElement(By.xpath("//select[@name='ctl00$ObeFlights1$ddlAdult']")));
		drop.selectByIndex(5);
	
		


	}

}
