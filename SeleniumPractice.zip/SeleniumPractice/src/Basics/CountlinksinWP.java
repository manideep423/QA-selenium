package Basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CountlinksinWP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new FirefoxDriver();
		driver.get("http://flipkart.com");
		driver.findElements(By.tagName("a")).size();
		System.out.println("Total num of links");
		System.out.println(driver.findElements(By.tagName("a")).size());
		WebElement footer= driver.findElement(By.xpath("html/body/div[1]/div/div/footer"));
		System.out.println("Footer links");
		System.out.println(footer.findElements(By.tagName("a")).size());
		
		
		WebElement col= driver.findElement(By.xpath("html/body/div[1]/div/div/footer/div/div[1]/div[1]/div[2]/div"));
		System.out.println("links only in column");
		System.out.println(col.findElements(By.tagName("a")).size());
		
		for (int i=0;i<col.findElements(By.tagName("a")).size();i++)
		{
			System.out.println(col.findElements(By.tagName("a")).get(i).getText());
		}
		
		
		
		
		/*WebElement fcol= driver.findElement(By.xpath("html/body/div[1]/div/div/footer/div/div[1]/div[1]/div[1]"));
		System.out.println("links only in column");
		System.out.println(fcol.findElements(By.tagName("a")).size());
		
		for(int i=0;i<fcol.findElements(By.tagName("a")).size();i++)
		{
		if (fcol.findElements(By.tagName("a")).get(i).getText().contains("FAQ"))
		{
			System.out.println(driver.getTitle());
			fcol.findElements(By.tagName("a")).get(i).click();
			
		}
		
		}*/
		
		
		System.out.println(driver.getTitle());
		

	}

}
