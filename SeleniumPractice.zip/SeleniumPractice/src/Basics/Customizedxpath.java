package Basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Customizedxpath {

	public static void main(String[] args) {
		/*// TODO Auto-generated method stub
		WebDriver loc=new FirefoxDriver();
		loc.get("http://facebook.com");
		loc.findElement(By.xpath("//input[@value='Log In']")).click();*/
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\MANI\\Downloads\\mani\\chromedriver.exe");
		WebDriver driv=new ChromeDriver();
		driv.get("http://salesforce.com");
		driv.findElement(By.linkText("LOGIN")).click();
		driv.findElement(By.cssSelector("input[class='input r4 wide mb16 mt8 username']")).sendKeys("mani");
		driv.findElement(By.xpath("//input[@name='pw']")).sendKeys("12345");
		driv.findElement(By.xpath("//input[@id='Login']")).click();

	}

}
