package Basics;



import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;


public class Cloudsauselab {
	@Test
	public void setup() throws MalformedURLException
	{
		DesiredCapabilities dc= DesiredCapabilities.firefox();
		dc.setCapability("version", "7");
		dc.setCapability("platform", "xp");
		
		
		WebDriver driv=new RemoteWebDriver(
				new URL("http://manireddy423:77ba6bcb-792a-41c8-83ea-1cc87f0685d3@ondemand.saucelabs.com:80/wd/hub "),
				dc);
		driv.get("http://google.com");
		System.out.println(driv.getTitle());
	}
	

}
