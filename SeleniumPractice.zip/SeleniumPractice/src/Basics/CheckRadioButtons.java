package Basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CheckRadioButtons {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driv=new FirefoxDriver();
		driv.get("http://www.coolfields.co.uk/2011/04/accessible-forms-checkboxes-and-radio-buttons/");
		driv.findElement(By.xpath("//input[@id='pizza2']")).click();
		driv.findElement(By.xpath("//input[@id='age2']")).click();
		driv.findElement(By.xpath("//input[@id='age2']")).isSelected();
		
		driv.findElement(By.xpath("//input[@id='trees1']")).click();
		System.out.println(driv.findElements(By.xpath("//input[name='trees']")).size());
	}

}
