package Basics;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Tables{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.sify.com/sports/cricket/ipl2016/standings/");
		
		WebElement score= driver.findElement(By.id("my-tab-content"));
		List<WebElement> asd=score.findElements(By.tagName("tr"));
		System.out.println("total num of rows"+asd.size());



	}
	

}
