package Basics;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class AdvancedwebUI {

	public static void main(String[] args) {
		/*// TODO Auto-generated method stub
		WebDriver driv=new FirefoxDriver();
		driv.get("http://flipcart.com");
		Actions abc=new Actions(driv);
		WebElement element=(driv.findElement(By.xpath("html/body/div[1]/div/div/header/div[1]/div/ul/li[7]/a/span[1]")));
		abc.moveToElement(element).build().perform();
		//WebElement xyz=(driv.findElement(By.xpath("html/body/div[1]/div/div/header/div[1]/div/ul/li[7]/a/span[1]")));
		
		WebElement pqr=(driv.findElement(By.xpath("html/body/div[1]/div/div/header/div[2]/div/div[2]" )));
		abc.keyDown(Keys.SHIFT).moveToElement(pqr).sendKeys("applelaptops").build().perform();
		abc.contextClick(pqr).build().perform();*/
		
		
		
		/*WebDriver driver=new FirefoxDriver();
		driver.get("http://rivier.edu");
		System.out.println(driver.getTitle());
		driver.findElement(By.xpath("html/body/div[3]/header/div[2]/div/div/ul[1]/li[2]/a")).click();
		
		Set<String> iff= driver.getWindowHandles();
		Iterator<String> as=iff.iterator();
		String parentid= as.next();
		String childid= as.next();
		driver.switchTo().window(childid);
		System.out.println(driver.getTitle());
		
		driver.switchTo().window(parentid);*/
		
		
		
		
		/*WebDriver abc=new FirefoxDriver();
		abc.get("https://mail.yahoo.com/");
		abc.findElement(By.cssSelector("#login-signup")).click();
		abc.findElement(By.xpath("html/body/div[1]/div[2]/div/div/p[2]/a[1]")).click();
		System.out.println(abc.getTitle());
		Set<String> asd= abc.getWindowHandles();
		Iterator<String> xy= asd.iterator();
		String parentid = xy.next();
		String childid = xy.next();
		abc.switchTo().window(childid);
		System.out.println(abc.getTitle());*/
		
		WebDriver abcd=new FirefoxDriver();
		abcd.get("https://accounts.google.com/SignUp?service=mail&continue=http%3A%2F%2Fmail.google.com%2Fmail%2F%3Fpc%3Dtopnav-about-en");
		abcd.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/p/a")).click();
		Set<String> man= abcd.getWindowHandles();
		Iterator<String> itt=man.iterator();
		String parentid= itt.next();
		String childid= itt.next();
		abcd.switchTo().window(childid);
		System.out.println(abcd.getTitle());
		
	
	
		
		
		
	
		
		
		
		
		
	
		
	}

}
