package Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Loadtesting {
	
	public void testing(){
		
		WebDriver driv=new FirefoxDriver();
		driv.get("http://ebay.com");
		System.out.println(driv.getTitle());
		
		
		
		
	}

}
