package Basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browsertrsting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driv=new FirefoxDriver();
		driv.get("http://www.tizag.com/javascriptT/javascriptalert.php");
		driv.findElement(By.xpath("html/body/table[3]/tbody/tr[1]/td[2]/table/tbody/tr/td/div[4]/form/input")).click();
		driv.switchTo().alert().accept();
		System.out.println(driv.switchTo().alert().getText());
		
				
	}

}
