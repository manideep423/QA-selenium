package Basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Javapopups {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driv=new FirefoxDriver();
		driv.get("http://www.tizag.com/javascriptT/javascriptalert.php");
		driv.findElement(By.xpath("html/body/table[3]/tbody/tr[1]/td[2]/table/tbody/tr/td/div[4]/form/input")).click();
		System.out.println(driv.switchTo().alert().getText());
		driv.switchTo().alert().accept();
		
	

		

	}

}
