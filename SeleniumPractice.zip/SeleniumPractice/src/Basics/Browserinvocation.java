package Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Browserinvocation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\MANI\\Downloads\\mani\\chromedriver.exe");
		System.setProperty("webdriver.ie.driver", "C:\\Users\\MANI\\Downloads\\mani\\IEDriverServer.EXE");
		WebDriver driv=new ChromeDriver();
		driv.get("http://saibersys.com");
		
		WebDriver driv1=new FirefoxDriver();
		driv1.get("http://saibersys.com");
		
		WebDriver driv2=new InternetExplorerDriver();
		driv2.get("http://google.com");
		
		System.out.println(driv.getTitle());
		System.out.println(driv.getPageSource());
		
		System.out.println(driv1.getTitle());
		System.out.println(driv1.getCurrentUrl());

		System.out.println(driv2.getPageSource());
		System.out.println(driv2.getTitle());
		
		
		
		
	}

}
